#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void Page(int a[], int n);
void Print(int a[]);
